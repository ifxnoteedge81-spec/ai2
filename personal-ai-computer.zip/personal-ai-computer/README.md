# PERSONAL AI COMPUTER

A local-first autonomous AI agent for Android (Kotlin, Jetpack Compose). No backend server: AI requests go
directly from the phone to **Google Gemini** or **OpenRouter** using your own API keys.

**v1 focus:** (1) AI brain + autonomous agent, (2) local Linux-style environment, (3) browser + virtual hands.
See [docs/PROJECT_CHECKLIST.md](docs/PROJECT_CHECKLIST.md) for exactly what is done, unverified, and planned.

## Status – read this first

| Item | State |
|---|---|
| Pure logic (command guard, tar extractor, workspace sandbox, agent protocol parser, SSRF guard, HTML→text, context trim) | Compiled with kotlinc and unit-tested (14 tests passing) in the authoring session |
| Android/Compose/OkHttp code (UI, providers, WebView, Accessibility, services) | Written, **not yet compiled**: the authoring sandbox could not reach Google/Maven. First real build happens in GitHub Actions |
| APK, Netlify deployment | **Not built or deployed yet.** Run the workflow once (below) and fix any compile errors it reports |
| On-device behaviour | **Not tested on a phone** |

## Get the APK (no local build needed)

1. Create a GitHub repository and push this folder to `main`.
2. In Netlify create an empty site (manual deploy). Copy its **Site ID** and create a **personal access token**.
3. GitHub → Settings → Secrets and variables → Actions → add `NETLIFY_AUTH_TOKEN` and `NETLIFY_SITE_ID`.
4. Optional but recommended, for a production-signed APK add `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`,
   `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD` (see [docs/BUILD.md](docs/BUILD.md)). Without them CI builds a debug-signed APK and says so.
5. Push to `main` (or run the workflow manually, or push a tag like `v1.0.0` for a GitHub Release).
6. Open your Netlify URL: the download button points at the APK built by that run, and CI verifies the SHA-256 of the deployed file.

Docs: [ARCHITECTURE](docs/ARCHITECTURE.md) · [BUILD](docs/BUILD.md) · [API_SETUP](docs/API_SETUP.md) · [SECURITY](docs/SECURITY.md) · [RUNTIME](docs/RUNTIME.md) · [NETLIFY_DEPLOYMENT](docs/NETLIFY_DEPLOYMENT.md)

## Honest limits

- PRoot is a user-space chroot, **not a virtual machine**; it is not bundled by default (see docs/RUNTIME.md). Without it the shell is Android's built-in toybox (no Python/Node/gcc).
- Android cannot reserve RAM for an app. The "RAM budget" is enforced as limits (context size, output caps, shell `ulimit -v`, step limits, one task at a time).
- Playwright cannot run in an Android app; browser automation uses WebView + injected JavaScript.
- Accessibility cannot see protected screens, and the agent never touches banking/wallet/password-manager/system-settings apps or this app's own screens.
- The agent never enters passwords, OTPs or CAPTCHAs.

License: MIT.
